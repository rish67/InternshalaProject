# Fantasy_cricket
Its a Fantasy cricket game made using python and sqlite database
